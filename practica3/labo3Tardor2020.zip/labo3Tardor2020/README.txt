Based on the example of miSudoku.pl, complete the following Prolog programs.
Use the Makefile and solve the problems in this order:

1.- roads.pl
2.- olympiad.pl
3.- tsp.pl

