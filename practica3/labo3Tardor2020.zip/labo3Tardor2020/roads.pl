% The government of a country with very few but very large roads needs
% to decide where to place gas stations.  It has been decided that if
% a road connects cities C1 and C2, a gas station should be placed in
% C1, C2, or both.  The government budget constraints the number of
% stations that can be built (maxStations).
% Complete the following program to do this.

%MANDATORY: Use the SAT variables: install-C "a gas station is installed in city C"
numCities(20).
maxStations(14).
road(18,19).
road(6,18).
road(1,12).
road(11,19).
road(3,15).
road(3,6).
road(2,15).
road(10,15).
road(4,7).
road(7,9).
road(12,13).
road(10,13).
road(13,20).
road(9,12).
road(13,14).
road(11,18).
road(3,8).
road(9,14).
road(19,20).
road(3,5).
road(10,14).
road(17,20).
road(3,11).
road(6,10).
road(9,18).
road(1,10).
road(2,4).
road(4,13).
road(15,17).
road(8,19).
road(2,8).
road(5,14).
road(7,9).
road(8,20).
road(4,10).
road(11,12).
road(7,12).
road(7,18).
road(2,14).
road(10,18).
road(6,11).
road(4,18).
road(6,20).
road(4,11).
road(8,18).
road(9,15).
road(5,13).
road(1,11).
road(10,17).
road(10,16).
road(3,20).
road(1,4).
road(16,18).
road(5,6).
road(11,16).
road(13,18).
road(10,20).
road(2,9).
road(1,18).
road(6,12).
road(9,19).
road(3,9).
road(15,16).
road(11,16).
road(12,16).
road(2,12).
road(12,15).
road(2,11).
road(1,19).
road(15,18).
road(11,13).
road(2,8).
road(2,13).
road(9,14).
road(7,17).
road(16,17).
% end input

%Helpful prolog predicates
city(C):- numCities(N), between(1,N,C).


%% displaySol
displaySol(M):- write(M), nl, findall(C,member(install-C,M),L), length(L,K), sort(L,L1),
		nl, write(K), write(' gas stations in cities: '), write(L1),fail.		
displaySol(_).

