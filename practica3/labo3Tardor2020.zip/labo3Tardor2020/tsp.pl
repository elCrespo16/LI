% We want to solve a modified version of the Traveling Salesman Problem: given a map with
% some (possibly one-way) roads between N cities, we want find a route starting and
% finishing in city 1 such that each city is visited exactly once. Moreover, we want to
% find a route with cost at most maxCost, considering that:
%  -trajects between cities with the same parity have cost 0 euros
%  -trajects between cities of different parity  have cost 1 euro
% For example, the following solution has cost 10:
%   1 10 4 8 3 20 18 14 12 11 15 2 5 9 17 16 7 13 19 6 1 
%    ^      ^ ^           ^     ^ ^      ^  ^       ^ ^
% Complete the following program to compute one such a route.
% MANDATORY: Use the SAT variable: visited-i-p meaning "city i is visited in position p"
% More variables might be needed.

%%% input:
maxCost(10).
numCities(20).
adjacency(1,[10]).
adjacency(2,[7,5,17]).  % Three one-way roads from city 2:  2->7, 2->5 and 2->17.
adjacency(3,[6,20,11]).
adjacency(4,[14,15,1,8,5]).
adjacency(5,[16,4,9,10,11]).
adjacency(6,[1,13,17]).
adjacency(7,[16,9,13,11]).
adjacency(8,[7,3,10,6,17]).
adjacency(9,[6,17,11]).
adjacency(10,[7,11,5,6,4]).
adjacency(11,[20,8,15,4,1,16,3]).
adjacency(12,[15,11,3]).
adjacency(13,[5,2,19,3,6]).
adjacency(14,[10,12,9,7]).
adjacency(15,[20,1,14,18,12,2]).
adjacency(16,[7,6,4,8,2,10]).
adjacency(17,[20,5,16,3,8]).
adjacency(18,[15,16,7,14,3]).
adjacency(19,[13,6]).
adjacency(20,[12,6,18,7,16]).
%%% end input


%Helpful prolog predicates:
position(P):- numCities(N), between(0,N,P).
city(I):-     adjacency(I,_).

%% displaySol:
displaySol(M):- position(P), member(visited-City-P,M), write(City), write(' '), fail.
displaySol(_):- nl.

