% For the next Catalan Computer Science Olympiad, we want to make the best possible
% team by selecting a set of students. For each student, we have the following information:
%
% 1.- Her ID
% 2.- The list of other students which she considers friends. Note that S1 could consider S2
%     as a friend, but the converse is not necessarily true.
% 3.- The programming topic she is most expert on.
%
% The goal is to form a team with exactly K students such that each one of them considers all other team members a friend
% and all chosen students haver different expertise topics.
%
% Complete the following program to find out one possible team.

% MANDATORY: Use SAT variables: chosen-S means "student S has been chosen"

%%% input:
numMembersTeam(6).
numStudents(25).
% info( id, list_of_students_(s)he_considers_a_friend, topic )
info(1,[4,9,11,14,15,16,21,23,24],t6).
info(2,[4,9,12,15,16,19,23],t8).
info(3,[3,7,10,11,12,13,15,17,21,22,24],t3).
info(4,[1,7,8,13,15,23,24],t4).
info(5,[1,8,9,11,13,17,18,23,24],t6).
info(6,[1,2,3,5,6,8,9,16,18,20,22,23,24],t6).
info(7,[5,10,11,12,14,20,25],t3).
info(8,[4,9,12,20,21],t1).
info(9,[3,6,9,15,20,23,24],t8).
info(10,[2,4,5,7,8,10,11,13,15,16,21,24],t8).
info(11,[1,3,5,11,12,14,15,17,20,22,24],t2).
info(12,[3,6,8,10,11,12,14,15,17,18,22],t5).
info(13,[2,4,6,8,10,13,15,18,19,24,25],t4).
info(14,[2,8,11,12,19],t4).
info(15,[3,4,6,11,12,14,15,16,17,22],t6).
info(16,[1,3,4,5,7,10,14,18,22,25],t3).
info(17,[2,3,9,11,12,14,15,16,17,19,20,22],t4).
info(18,[4,5,7,10,11,14,17,18,20,24],t8).
info(19,[3,4,7,19,24],t4).
info(20,[1,2,3,6,11,13,19],t8).
info(21,[1,10,17,19,23,24,25],t8).
info(22,[3,4,11,12,13,15,16,17,20,22],t1).
info(23,[6,11,21,24],t4).
info(24,[2,6,12,13,15,18,19,20,21,23,25],t7).
info(25,[1,3,8,10,13,18,20,21,24],t3)    
%%% end input


%Helpful prolog predicates:
student(S):-     numStudents(N), between(0,N,S).
friends(S1,S2):- student(S1), student(S2), info(S1,L,_), member(S2,L).
expertise(S,E):- student(S), info(S,_,E).


%% displaySol:
displaySol(M):- write('Team: '), nl, student(S), member(chosen-S, M), expertise(S,E), write(S-E), nl, fail.
displaySol(_):- nl.
